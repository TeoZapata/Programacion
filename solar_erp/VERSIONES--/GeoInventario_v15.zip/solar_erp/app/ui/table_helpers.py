"""
Helpers centralizados para configurar tablas QTableWidget en GeoInventario.
Aplica: redimensionado interactivo de columnas, tooltips automáticos en hover,
        y botones de acta PDF correctamente dimensionados.
"""
from PySide6.QtWidgets import QHeaderView, QTableWidget, QTableWidgetItem, QPushButton
from PySide6.QtCore import Qt


def configurar_tabla(tabla: QTableWidget,
                     col_stretch: int = 0,
                     cols_fijas: list = None,
                     altura_fila: int = 34):
    """
    Configura una QTableWidget con:
    - Columnas interactivas (el usuario puede arrastrar el ancho)
    - Una columna que se estira para ocupar el espacio restante
    - Tooltip automático en cada celda con el texto completo
    - Altura de fila consistente
    """
    hdr = tabla.horizontalHeader()

    # Modo interactivo base — el usuario puede arrastrar cualquier columna
    hdr.setSectionResizeMode(QHeaderView.Interactive)
    hdr.setStretchLastSection(False)

    # La columna designada absorbe el espacio sobrante
    if col_stretch is not None and tabla.columnCount() > col_stretch:
        hdr.setSectionResizeMode(col_stretch, QHeaderView.Stretch)

    # Columnas con ancho fijo (e.g. botones, IDs)
    if cols_fijas:
        for col, ancho in cols_fijas:
            if col < tabla.columnCount():
                hdr.setSectionResizeMode(col, QHeaderView.Fixed)
                tabla.setColumnWidth(col, ancho)

    # Altura de filas uniforme
    tabla.verticalHeader().setDefaultSectionSize(altura_fila)

    # Tooltip automático: conectar señal del header para que el usuario
    # vea el contenido completo de cada celda al pasar el cursor.
    # Se instala a nivel de tabla con evento personalizado.
    tabla.setMouseTracking(True)
    tabla.__class__ = _TablaConTooltip   # reemplaza la clase en caliente


class _TablaConTooltip(QTableWidget):
    """QTableWidget con tooltip automático en cada celda."""

    def mouseMoveEvent(self, event):
        index = self.indexAt(event.pos())
        if index.isValid():
            item = self.item(index.row(), index.column())
            widget = self.cellWidget(index.row(), index.column())
            if item and item.text():
                self.setToolTip(item.text())
            elif widget:
                self.setToolTip(widget.toolTip() or "")
            else:
                self.setToolTip("")
        else:
            self.setToolTip("")
        super().mouseMoveEvent(event)


def set_item_tooltip(item: QTableWidgetItem, extra: str = ""):
    """Asigna el tooltip de un QTableWidgetItem igual a su texto."""
    if item:
        tip = item.text()
        if extra:
            tip = f"{tip}\n{extra}"
        item.setToolTip(tip)
    return item


def make_item(texto: str, tooltip: str = None, **kwargs) -> QTableWidgetItem:
    """Crea un QTableWidgetItem con tooltip automático."""
    it = QTableWidgetItem(str(texto) if texto is not None else "—")
    it.setToolTip(tooltip if tooltip is not None else it.text())
    return it


def btn_acta(label: str = "📄 Acta PDF", color_bg: str = "#EBF5FB",
             color_txt: str = "#1E3A5F", color_border: str = "#AED6F1",
             color_hover: str = "#AED6F1", tooltip: str = "Ver / generar acta PDF") -> QPushButton:
    """
    Crea un botón de acta PDF estandarizado, legible y con buen tamaño.
    """
    btn = QPushButton(label)
    btn.setMinimumHeight(28)
    btn.setMinimumWidth(95)
    btn.setToolTip(tooltip)
    btn.setStyleSheet(
        f"QPushButton {{"
        f"  background: {color_bg}; color: {color_txt};"
        f"  border: 1px solid {color_border}; border-radius: 5px;"
        f"  font-size: 11px; font-weight: bold; padding: 3px 10px;"
        f"}}"
        f"QPushButton:hover {{ background: {color_hover}; }}"
        f"QPushButton:pressed {{ background: {color_border}; }}"
    )
    return btn


def btn_acta_movimiento(tooltip: str = "Ver acta del movimiento") -> QPushButton:
    return btn_acta("📄 Acta PDF", "#EBF5FB", "#1E3A5F", "#AED6F1", "#AED6F1", tooltip)


def btn_acta_pedido(tooltip: str = "Ver acta del pedido") -> QPushButton:
    return btn_acta("📄 Pedido PDF", "#F5EEF8", "#9B59B6", "#D7BDE2", "#D7BDE2", tooltip)
