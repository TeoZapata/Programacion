from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QDialog,
    QFormLayout, QComboBox, QDateEdit, QLineEdit, QTextEdit,
    QDoubleSpinBox, QMessageBox, QTabWidget, QFrame, QScrollArea,
    QAbstractItemView
)
from PySide6.QtCore import Qt, QDate
from PySide6.QtGui import QColor, QFont
from app.core.database import SessionLocal
from app.services.services import (
    MovimientoService, InventarioService, ProyectoService,
    ProveedorService, TrabajadorService
)
import os
import subprocess
import platform


class MovimientosView(QWidget):
    def __init__(self, usuario=None):
        super().__init__()
        self.usuario = usuario
        self._build_ui()
        self._cargar_tabla()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 22, 28, 22)
        layout.setSpacing(16)

        titulo = QLabel("🔄  Movimientos de Inventario")
        titulo.setStyleSheet("font-size: 22px; font-weight: bold; color: #1E3A5F;")
        layout.addWidget(titulo)

        # Botones de acción
        btns_layout = QHBoxLayout()
        btns_layout.setSpacing(10)

        btn_entrada = QPushButton("⬆️  Registrar Entrada")
        btn_entrada.setObjectName("btn_success")
        btn_entrada.setMinimumHeight(40)
        btn_entrada.clicked.connect(self._nueva_entrada)
        btns_layout.addWidget(btn_entrada)

        btn_salida = QPushButton("⬇️  Registrar Salida")
        btn_salida.setObjectName("btn_primary")
        btn_salida.setMinimumHeight(40)
        btn_salida.clicked.connect(self._nueva_salida)
        btns_layout.addWidget(btn_salida)

        btn_devolucion = QPushButton("↩️  Registrar Devolución")
        btn_devolucion.setObjectName("btn_warning")
        btn_devolucion.setMinimumHeight(40)
        btn_devolucion.clicked.connect(self._nueva_devolucion)
        btns_layout.addWidget(btn_devolucion)

        btns_layout.addStretch()

        btn_refrescar = QPushButton("↻  Refrescar")
        btn_refrescar.setObjectName("btn_secondary")
        btn_refrescar.clicked.connect(self._cargar_tabla)
        btns_layout.addWidget(btn_refrescar)

        layout.addLayout(btns_layout)

        # Tabla
        cols = ["ID", "Tipo", "Proyecto / Proveedor", "Responsable", "Fecha", "Factura", "Materiales", "Acciones"]
        self.tabla = QTableWidget(0, len(cols))
        self.tabla.setHorizontalHeaderLabels(cols)
        self.tabla.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tabla.setEditTriggers(QTableWidget.NoEditTriggers)
        self.tabla.setSelectionBehavior(QTableWidget.SelectRows)
        self.tabla.setAlternatingRowColors(True)
        self.tabla.verticalHeader().setVisible(False)
        layout.addWidget(self.tabla)

        self.lbl_total = QLabel("Total: 0 registros")
        self.lbl_total.setStyleSheet("color: #7F8C8D; font-size: 12px;")
        layout.addWidget(self.lbl_total)

    def _cargar_tabla(self):
        db = SessionLocal()
        movimientos = MovimientoService(db).ultimos(100)
        db.close()

        self.tabla.setRowCount(0)
        iconos = {"entrada": "⬆️", "salida": "⬇️", "devolucion": "↩️"}
        colores = {"entrada": "#2ECC71", "salida": "#1E3A5F", "devolucion": "#F39C12"}

        for mv in movimientos:
            row = self.tabla.rowCount()
            self.tabla.insertRow(row)
            self.tabla.setItem(row, 0, QTableWidgetItem(str(mv.id)))

            tipo_item = QTableWidgetItem(f"{iconos.get(mv.tipo, '')}  {mv.tipo.capitalize()}")
            tipo_item.setForeground(QColor(colores.get(mv.tipo, "#2C3E50")))
            tipo_item.setFont(QFont("", -1, QFont.Bold))
            self.tabla.setItem(row, 1, tipo_item)

            ref = mv.proyecto.nombre_proyecto if mv.proyecto else (mv.proveedor.nombre if mv.proveedor else "—")
            self.tabla.setItem(row, 2, QTableWidgetItem(ref))
            self.tabla.setItem(row, 3, QTableWidgetItem(mv.responsable or "—"))
            self.tabla.setItem(row, 4, QTableWidgetItem(str(mv.fecha)))
            self.tabla.setItem(row, 5, QTableWidgetItem(mv.factura or "—"))
            n_items = len(mv.detalles)
            self.tabla.setItem(row, 6, QTableWidgetItem(f"{n_items} material(es)"))

            # Botón generar acta PDF (entrada, salida y devolución)
            if mv.tipo in ("entrada", "salida", "devolucion"):
                btn_acta = QPushButton("📄 Acta PDF")
                btn_acta.setObjectName("btn_secondary")
                btn_acta.setFixedHeight(28)
                btn_acta.clicked.connect(lambda _, m=mv: self._generar_acta(m))
                self.tabla.setCellWidget(row, 7, btn_acta)

        self.lbl_total.setText(f"Total: {self.tabla.rowCount()} registros")

    def _nueva_entrada(self):
        dlg = EntradaDialog(self, usuario=self.usuario)
        if dlg.exec():
            self._cargar_tabla()

    def _nueva_salida(self):
        dlg = SalidaDialog(self, usuario=self.usuario)
        if dlg.exec():
            self._cargar_tabla()

    def _nueva_devolucion(self):
        dlg = DevolucionDialog(self, usuario=self.usuario)
        if dlg.exec():
            self._cargar_tabla()

    def _generar_acta(self, movimiento):
        db = SessionLocal()
        try:
            if movimiento.tipo == "entrada":
                from app.reports.acta_pdf import generar_acta_entrada_pdf
                ruta = generar_acta_entrada_pdf(
                    movimiento=movimiento,
                    proveedor=movimiento.proveedor,
                    detalles=movimiento.detalles,
                    responsable=movimiento.responsable,
                )
            elif movimiento.tipo == "salida":
                from app.reports.acta_pdf import generar_acta_salida_pdf
                ruta = generar_acta_salida_pdf(
                    movimiento=movimiento,
                    proyecto=movimiento.proyecto,
                    cliente=movimiento.proyecto.cliente if movimiento.proyecto else None,
                    detalles=movimiento.detalles,
                    responsable=movimiento.responsable,
                )
            else:  # devolucion
                from app.reports.acta_pdf import generar_acta_devolucion_pdf
                ruta = generar_acta_devolucion_pdf(
                    movimiento=movimiento,
                    proyecto=movimiento.proyecto,
                    cliente=movimiento.proyecto.cliente if movimiento.proyecto else None,
                    detalles=movimiento.detalles,
                    responsable=movimiento.responsable,
                )
            resp = QMessageBox.question(
                self, "Acta PDF generada",
                f"Acta generada exitosamente:\n{ruta}\n\n¿Deseas abrirla?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes,
            )
            if resp == QMessageBox.Yes:
                self._abrir_archivo(ruta)
        except Exception as e:
            QMessageBox.warning(self, "Error", f"No se pudo generar el acta: {e}")
        finally:
            db.close()

    def _abrir_archivo(self, ruta):
        try:
            if platform.system() == "Windows":
                os.startfile(ruta)
            elif platform.system() == "Darwin":
                subprocess.call(["open", ruta])
            else:
                subprocess.call(["xdg-open", ruta])
        except Exception:
            pass


class ItemsMovimientoWidget(QWidget):
    """Widget reutilizable para agregar ítems de material al movimiento."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        db = SessionLocal()
        materiales = InventarioService(db).listar()
        db.close()
        self.materiales_map = {m.id: m for m in materiales}

        # ── Fila de selección ────────────────────────────────────────────────
        add_row = QHBoxLayout()
        add_row.setSpacing(8)

        self.combo_mat = QComboBox()
        self.combo_mat.setMinimumWidth(220)
        for m in materiales:
            self.combo_mat.addItem(
                f"{m.nombre_material} ({m.cantidad_actual} {m.unidad})", m.id)
        self.combo_mat.currentIndexChanged.connect(self._on_material_changed)
        add_row.addWidget(self.combo_mat)

        self.spin_cant = QDoubleSpinBox()
        self.spin_cant.setRange(0.01, 99999)
        self.spin_cant.setDecimals(2)
        self.spin_cant.setValue(1)
        self.spin_cant.setFixedWidth(100)
        self.spin_cant.setToolTip("Cantidad")
        self.spin_cant.valueChanged.connect(self._actualizar_subtotal)
        add_row.addWidget(self.spin_cant)

        self.spin_precio = QDoubleSpinBox()
        self.spin_precio.setRange(0, 999_999_999)
        self.spin_precio.setDecimals(2)
        self.spin_precio.setPrefix("$ ")
        self.spin_precio.setFixedWidth(140)
        self.spin_precio.setToolTip("Precio unitario")
        self.spin_precio.valueChanged.connect(self._actualizar_subtotal)
        add_row.addWidget(self.spin_precio)

        self.lbl_subtotal = QLabel("= $ 0.00")
        self.lbl_subtotal.setStyleSheet("color: #1E3A5F; font-weight: bold; min-width: 110px;")
        add_row.addWidget(self.lbl_subtotal)

        btn_add = QPushButton("＋ Agregar")
        btn_add.setObjectName("btn_success")
        btn_add.clicked.connect(self._agregar_item)
        add_row.addWidget(btn_add)
        layout.addLayout(add_row)

        # ── Tabla de ítems ───────────────────────────────────────────────────
        self.tabla_items = QTableWidget(0, 5)
        self.tabla_items.setHorizontalHeaderLabels(
            ["Material", "Cantidad", "Precio Unit.", "Valor Total", ""])
        self.tabla_items.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tabla_items.setMaximumHeight(220)
        self.tabla_items.verticalHeader().setVisible(False)
        self.tabla_items.setStyleSheet("QTableWidget { border: 1px solid #DDE2E8; }")
        layout.addWidget(self.tabla_items)

        # ── Total general ────────────────────────────────────────────────────
        total_row = QHBoxLayout()
        total_row.addStretch()
        self.lbl_total = QLabel("Total: $ 0.00")
        self.lbl_total.setStyleSheet(
            "font-size: 13px; font-weight: bold; color: #1E3A5F; padding: 4px 8px;"
            "background: #EBF5FB; border-radius: 6px;")
        total_row.addWidget(self.lbl_total)
        layout.addLayout(total_row)

        # Inicializar precio con el primer material
        self._on_material_changed()

    def _on_material_changed(self):
        mat_id = self.combo_mat.currentData()
        mat = self.materiales_map.get(mat_id)
        if mat and mat.precio_unitario:
            self.spin_precio.setValue(mat.precio_unitario)
        else:
            self.spin_precio.setValue(0)
        self._actualizar_subtotal()

    def _actualizar_subtotal(self):
        sub = self.spin_cant.value() * self.spin_precio.value()
        self.lbl_subtotal.setText(f"= $ {sub:,.2f}")

    def _recalcular_total(self):
        total = 0.0
        for row in range(self.tabla_items.rowCount()):
            item = self.tabla_items.item(row, 3)
            if item:
                try:
                    total += float(item.data(256))  # UserRole
                except Exception:
                    pass
        self.lbl_total.setText(f"Total: $ {total:,.2f}")

    def _agregar_item(self):
        mat_id   = self.combo_mat.currentData()
        cantidad = self.spin_cant.value()
        precio   = self.spin_precio.value()
        if not mat_id:
            return
        mat = self.materiales_map.get(mat_id)
        valor = round(cantidad * precio, 2)

        row = self.tabla_items.rowCount()
        self.tabla_items.insertRow(row)
        self.tabla_items.setItem(row, 0, QTableWidgetItem(
            mat.nombre_material if mat else str(mat_id)))
        self.tabla_items.setItem(row, 1, QTableWidgetItem(str(cantidad)))
        pu_item = QTableWidgetItem(f"$ {precio:,.2f}")
        pu_item.setForeground(QColor("#1E3A5F"))
        self.tabla_items.setItem(row, 2, pu_item)
        vt_item = QTableWidgetItem(f"$ {valor:,.2f}")
        vt_item.setForeground(QColor("#27AE60"))
        vt_item.setFont(QFont("", -1, QFont.Bold))
        vt_item.setData(256, valor)   # guardar valor numérico en UserRole
        self.tabla_items.setItem(row, 3, vt_item)

        btn_rem = QPushButton("✕")
        btn_rem.setObjectName("btn_danger")
        btn_rem.setFixedSize(28, 28)
        btn_rem.clicked.connect(lambda _, r=row: self._quitar_item(r))
        self.tabla_items.setCellWidget(row, 4, btn_rem)
        self._recalcular_total()

    def _quitar_item(self, row):
        self.tabla_items.removeRow(row)
        self._recalcular_total()

    def get_items(self):
        """Retorna lista de (mat_id, cantidad, precio_unitario)."""
        items = []
        for row in range(self.tabla_items.rowCount()):
            mat_nombre = self.tabla_items.item(row, 0).text()
            cantidad   = float(self.tabla_items.item(row, 1).text())
            precio_txt = self.tabla_items.item(row, 2).text().replace("$", "").replace(",", "").strip()
            precio     = float(precio_txt)
            mat_id = None
            for mid, m in self.materiales_map.items():
                if m.nombre_material == mat_nombre:
                    mat_id = mid; break
            if mat_id:
                items.append((mat_id, cantidad, precio))
        return items


class EntradaDialog(QDialog):
    def __init__(self, parent=None, usuario=None):
        super().__init__(parent)
        self.usuario = usuario
        self.setWindowTitle("Registrar Entrada de Material")
        self.setMinimumWidth(600)
        self.setModal(True)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(25, 25, 25, 25)
        layout.setSpacing(14)

        titulo = QLabel("⬆️  Entrada de Material")
        titulo.setStyleSheet("font-size: 16px; font-weight: bold; color: #2ECC71;")
        layout.addWidget(titulo)

        form = QFormLayout()
        form.setSpacing(10)

        self.combo_proveedor = QComboBox()
        db = SessionLocal()
        proveedores = ProveedorService(db).listar()
        db.close()
        self.combo_proveedor.addItem("Seleccionar proveedor...", None)
        for p in proveedores:
            self.combo_proveedor.addItem(p.nombre, p.id)
        form.addRow("Proveedor *", self.combo_proveedor)

        self.input_factura = QLineEdit(); self.input_factura.setPlaceholderText("Nro. de factura")
        form.addRow("Factura", self.input_factura)

        self.date_mov = QDateEdit(QDate.currentDate())
        self.date_mov.setCalendarPopup(True)
        self.date_mov.setDisplayFormat("dd/MM/yyyy")
        form.addRow("Fecha", self.date_mov)

        self.input_resp = QLineEdit()
        self.input_resp.setText(self.usuario.nombre if self.usuario else "")
        form.addRow("Responsable", self.input_resp)

        self.input_obs = QLineEdit(); self.input_obs.setPlaceholderText("Observaciones (opcional)")
        form.addRow("Observaciones", self.input_obs)
        layout.addLayout(form)

        lbl_mat = QLabel("Materiales a ingresar")
        lbl_mat.setStyleSheet("font-weight: bold; color: #2C3E50;")
        layout.addWidget(lbl_mat)

        self.items_widget = ItemsMovimientoWidget()
        layout.addWidget(self.items_widget)

        btns = QHBoxLayout()
        btns.addStretch()
        btn_cancelar = QPushButton("Cancelar"); btn_cancelar.setObjectName("btn_secondary")
        btn_cancelar.clicked.connect(self.reject)
        btns.addWidget(btn_cancelar)
        btn_guardar = QPushButton("💾  Registrar Entrada"); btn_guardar.setObjectName("btn_success")
        btn_guardar.clicked.connect(self._guardar)
        btns.addWidget(btn_guardar)
        layout.addLayout(btns)

    def _guardar(self):
        proveedor_id = self.combo_proveedor.currentData()
        items = self.items_widget.get_items()
        if not items:
            QMessageBox.warning(self, "Validación", "Agrega al menos un material.")
            return
        db = SessionLocal()
        try:
            mov = MovimientoService(db).registrar_entrada(
                proveedor_id=proveedor_id,
                factura=self.input_factura.text().strip(),
                fecha=self.date_mov.date().toPython(),
                responsable=self.input_resp.text().strip(),
                observaciones=self.input_obs.text().strip(),
                items=[(i[0], i[1], i[2]) for i in items],
            )
            # Generar acta PDF automáticamente
            try:
                from app.reports.acta_pdf import generar_acta_entrada_pdf
                ruta = generar_acta_entrada_pdf(
                    movimiento=mov,
                    proveedor=mov.proveedor,
                    detalles=mov.detalles,
                    responsable=mov.responsable,
                )
                resp = QMessageBox.question(
                    self, "Entrada registrada",
                    f"Entrada registrada correctamente.\nActa PDF generada:\n{ruta}\n\n¿Deseas abrirla?",
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes,
                )
                if resp == QMessageBox.Yes:
                    import os, subprocess, platform
                    if platform.system() == "Windows":
                        os.startfile(ruta)
                    elif platform.system() == "Darwin":
                        subprocess.call(["open", ruta])
                    else:
                        subprocess.call(["xdg-open", ruta])
            except Exception as e_pdf:
                QMessageBox.information(self, "Entrada registrada",
                    f"Entrada registrada correctamente.\nNo se pudo generar el acta PDF: {e_pdf}")
            self.accept()
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))
        finally:
            db.close()


class SalidaDialog(QDialog):
    def __init__(self, parent=None, usuario=None):
        super().__init__(parent)
        self.usuario = usuario
        self.setWindowTitle("Registrar Salida de Material")
        self.setMinimumWidth(600)
        self.setModal(True)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(25, 25, 25, 25)
        layout.setSpacing(14)

        titulo = QLabel("⬇️  Salida de Material por Proyecto")
        titulo.setStyleSheet("font-size: 16px; font-weight: bold; color: #1E3A5F;")
        layout.addWidget(titulo)

        form = QFormLayout()
        form.setSpacing(10)

        self.combo_proyecto = QComboBox()
        db = SessionLocal()
        proyectos = ProyectoService(db).listar()
        db.close()
        self.combo_proyecto.addItem("Seleccionar proyecto...", None)
        for p in proyectos:
            self.combo_proyecto.addItem(f"{p.nombre_proyecto} — {p.cliente.nombre if p.cliente else ''}", p.id)
        form.addRow("Proyecto *", self.combo_proyecto)

        self.date_mov = QDateEdit(QDate.currentDate())
        self.date_mov.setCalendarPopup(True)
        self.date_mov.setDisplayFormat("dd/MM/yyyy")
        form.addRow("Fecha", self.date_mov)

        self.input_resp = QLineEdit()
        self.input_resp.setText(self.usuario.nombre if self.usuario else "")
        form.addRow("Responsable", self.input_resp)

        self.input_obs = QLineEdit(); self.input_obs.setPlaceholderText("Observaciones (opcional)")
        form.addRow("Observaciones", self.input_obs)
        layout.addLayout(form)

        lbl_mat = QLabel("Materiales a entregar")
        lbl_mat.setStyleSheet("font-weight: bold; color: #2C3E50;")
        layout.addWidget(lbl_mat)

        self.items_widget = ItemsMovimientoWidget()
        self.items_widget.spin_precio.setVisible(False)
        layout.addWidget(self.items_widget)

        lbl_acta = QLabel("💡 Se generará un Acta de Entrega de Materiales en Word")
        lbl_acta.setStyleSheet("color: #7F8C8D; font-size: 12px; font-style: italic;")
        layout.addWidget(lbl_acta)

        btns = QHBoxLayout()
        btns.addStretch()
        btn_cancelar = QPushButton("Cancelar"); btn_cancelar.setObjectName("btn_secondary")
        btn_cancelar.clicked.connect(self.reject)
        btns.addWidget(btn_cancelar)
        btn_guardar = QPushButton("💾  Registrar Salida + Generar Acta"); btn_guardar.setObjectName("btn_primary")
        btn_guardar.clicked.connect(self._guardar)
        btns.addWidget(btn_guardar)
        layout.addLayout(btns)

    def _guardar(self):
        proyecto_id = self.combo_proyecto.currentData()
        items = self.items_widget.get_items()
        if not proyecto_id:
            QMessageBox.warning(self, "Validación", "Selecciona un proyecto.")
            return
        if not items:
            QMessageBox.warning(self, "Validación", "Agrega al menos un material.")
            return
        db = SessionLocal()
        try:
            svc = MovimientoService(db)
            mov = svc.registrar_salida(
                proyecto_id=proyecto_id,
                fecha=self.date_mov.date().toPython(),
                responsable=self.input_resp.text().strip(),
                observaciones=self.input_obs.text().strip(),
                items=[(i[0], i[1]) for i in items],
            )
            # Generar acta Word
            try:
                from app.reports.acta_materiales import generar_acta_materiales
                mov_completo = svc.repo.get_by_id(mov.id)
                ruta = generar_acta_materiales(
                    movimiento=mov_completo,
                    proyecto=mov_completo.proyecto,
                    cliente=mov_completo.proyecto.cliente if mov_completo.proyecto else None,
                    detalles=mov_completo.detalles,
                    responsable=mov_completo.responsable,
                )
                QMessageBox.information(self, "Éxito",
                    f"Salida registrada y Acta generada:\n{ruta}")
            except Exception as e_doc:
                QMessageBox.information(self, "Salida registrada",
                    f"Salida registrada. No se pudo generar el acta: {e_doc}")
            self.accept()
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))
        finally:
            db.close()


class DevolucionDialog(QDialog):
    def __init__(self, parent=None, usuario=None):
        super().__init__(parent)
        self.usuario = usuario
        self.setWindowTitle("Registrar Devolución de Material")
        self.setMinimumWidth(580)
        self.setModal(True)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(25, 25, 25, 25)
        layout.setSpacing(14)

        titulo = QLabel("↩️  Devolución de Material")
        titulo.setStyleSheet("font-size: 16px; font-weight: bold; color: #F39C12;")
        layout.addWidget(titulo)

        form = QFormLayout()
        form.setSpacing(10)

        self.combo_proyecto = QComboBox()
        db = SessionLocal()
        proyectos = ProyectoService(db).listar()
        db.close()
        self.combo_proyecto.addItem("Seleccionar proyecto...", None)
        for p in proyectos:
            self.combo_proyecto.addItem(f"{p.nombre_proyecto}", p.id)
        form.addRow("Proyecto", self.combo_proyecto)

        self.date_mov = QDateEdit(QDate.currentDate())
        self.date_mov.setCalendarPopup(True)
        self.date_mov.setDisplayFormat("dd/MM/yyyy")
        form.addRow("Fecha", self.date_mov)

        self.input_resp = QLineEdit()
        self.input_resp.setText(self.usuario.nombre if self.usuario else "")
        form.addRow("Responsable", self.input_resp)

        self.input_obs = QLineEdit(); self.input_obs.setPlaceholderText("Motivo de la devolución")
        form.addRow("Observaciones", self.input_obs)
        layout.addLayout(form)

        lbl_mat = QLabel("Materiales a devolver")
        lbl_mat.setStyleSheet("font-weight: bold; color: #2C3E50;")
        layout.addWidget(lbl_mat)

        self.items_widget = ItemsMovimientoWidget()
        self.items_widget.spin_precio.setVisible(False)
        layout.addWidget(self.items_widget)

        btns = QHBoxLayout()
        btns.addStretch()
        btn_cancelar = QPushButton("Cancelar"); btn_cancelar.setObjectName("btn_secondary")
        btn_cancelar.clicked.connect(self.reject)
        btns.addWidget(btn_cancelar)
        btn_guardar = QPushButton("💾  Registrar Devolución"); btn_guardar.setObjectName("btn_warning")
        btn_guardar.clicked.connect(self._guardar)
        btns.addWidget(btn_guardar)
        layout.addLayout(btns)

    def _guardar(self):
        items = self.items_widget.get_items()
        if not items:
            QMessageBox.warning(self, "Validación", "Agrega al menos un material.")
            return
        db = SessionLocal()
        try:
            mov = MovimientoService(db).registrar_devolucion(
                proyecto_id=self.combo_proyecto.currentData(),
                fecha=self.date_mov.date().toPython(),
                responsable=self.input_resp.text().strip(),
                observaciones=self.input_obs.text().strip(),
                items=[(i[0], i[1]) for i in items],
            )
            # Generar acta PDF automáticamente
            try:
                from app.reports.acta_pdf import generar_acta_devolucion_pdf
                ruta = generar_acta_devolucion_pdf(
                    movimiento=mov,
                    proyecto=mov.proyecto,
                    cliente=mov.proyecto.cliente if mov.proyecto else None,
                    detalles=mov.detalles,
                    responsable=mov.responsable,
                )
                resp = QMessageBox.question(
                    self, "Devolución registrada",
                    f"Devolución registrada correctamente.\nActa PDF generada:\n{ruta}\n\n¿Deseas abrirla?",
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes,
                )
                if resp == QMessageBox.Yes:
                    import os, subprocess, platform
                    if platform.system() == "Windows":
                        os.startfile(ruta)
                    elif platform.system() == "Darwin":
                        subprocess.call(["open", ruta])
                    else:
                        subprocess.call(["xdg-open", ruta])
            except Exception as e_pdf:
                QMessageBox.information(self, "Devolución registrada",
                    f"Devolución registrada correctamente.\nNo se pudo generar el acta PDF: {e_pdf}")
            self.accept()
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))
        finally:
            db.close()
